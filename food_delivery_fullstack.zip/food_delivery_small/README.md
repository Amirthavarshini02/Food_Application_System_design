# Food Delivery Demo (Small Full-Stack Project)

A simple food delivery prototype with a React frontend, Express backend, MongoDB persistence, and optional RabbitMQ notifications.

## Features
- Browse restaurants and menus
- Add/remove items in a cart
- Place a demo order
- Track order status
- Restaurant dashboard to accept/reject orders and update status
- RabbitMQ fanout notification publishing (optional; app still runs without RabbitMQ)

## Requirements
- Node.js 18+
- MongoDB running locally (or set `MONGODB_URI`)
- RabbitMQ is optional (only needed for broker notifications)

## Run backend
```bash
cd backend
cp .env.example .env
npm install
npm run dev
```
Backend defaults to `http://localhost:5000`. If MongoDB is unavailable, it uses in-memory demo data so the basic app can still be tested. Data will reset when the backend restarts.

## Run frontend
Open a second terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the URL printed by Vite (usually `http://localhost:5173`).

## Optional RabbitMQ
Set `RABBITMQ_URL=amqp://localhost` in `backend/.env` and start RabbitMQ. If the broker is unavailable, orders still work; the backend logs a warning and skips publishing.

## Demo notes
- Payments are simulated only; no real payment gateway is connected.
- This is a small teaching/demo app, not production-ready.
- The app uses a simple demo restaurant dashboard without authentication. Add JWT and role checks before any real deployment.
