import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import mongoose from "mongoose";
import amqp from "amqplib";

dotenv.config();
const app = express();
app.use(cors({ origin: "http://localhost:5173" }));
app.use(express.json());

const menuSeed = [
  { _id: "m1", name: "Margherita Pizza", restaurant: "Urban Oven", category: "Pizza", price: 249, available: true, emoji: "🍕" },
  { _id: "m2", name: "Classic Burger", restaurant: "Burger House", category: "Burgers", price: 159, available: true, emoji: "🍔" },
  { _id: "m3", name: "Paneer Wrap", restaurant: "Green Bowl", category: "Wraps", price: 129, available: true, emoji: "🌯" },
  { _id: "m4", name: "Masala Dosa", restaurant: "South Spice", category: "South Indian", price: 99, available: true, emoji: "🥞" },
  { _id: "m5", name: "Chocolate Brownie", restaurant: "Sweet Spot", category: "Desserts", price: 89, available: true, emoji: "🍫" },
  { _id: "m6", name: "Crispy Fries", restaurant: "Burger House", category: "Sides", price: 79, available: true, emoji: "🍟" }
];
let memoryOrders = [];
let memoryMenu = [...menuSeed];
let mongoReady = false;
let rabbitChannel = null;

const MenuSchema = new mongoose.Schema({
  name: String, restaurant: String, category: String, price: Number, available: Boolean, emoji: String
});
const OrderSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  address: { type: String, required: true },
  items: [{ itemId: String, name: String, price: Number, quantity: Number }],
  total: Number,
  paymentMethod: String,
  paymentStatus: String,
  status: String,
  createdAt: { type: Date, default: Date.now }
});
const MenuModel = mongoose.model("MenuItem", MenuSchema);
const OrderModel = mongoose.model("Order", OrderSchema);

async function publishEvent(event) {
  if (!rabbitChannel) return;
  rabbitChannel.publish("food.events", "", Buffer.from(JSON.stringify(event)), { persistent: true, contentType: "application/json" });
}

app.get("/api/health", (_req, res) => res.json({ status: "ok", database: mongoReady ? "mongodb" : "memory-demo", rabbitmq: rabbitChannel ? "connected" : "offline" }));

app.get("/api/restaurants", (_req, res) => {
  const names = [...new Set(memoryMenu.map(x => x.restaurant))];
  res.json(names.map((name, i) => ({ id: i + 1, name, cuisine: name === "South Spice" ? "South Indian" : "Popular", rating: (4.2 + (i % 7) / 10).toFixed(1), deliveryMinutes: 20 + i * 5 })));
});

app.get("/api/menu", async (_req, res) => {
  if (mongoReady) {
    const items = await MenuModel.find().lean();
    if (items.length) return res.json(items.map(x => ({ ...x, _id: String(x._id) })));
  }
  res.json(memoryMenu);
});

app.patch("/api/menu/:id", async (req, res) => {
  const { price, available } = req.body;
  if (price !== undefined && (!Number.isFinite(Number(price)) || Number(price) <= 0)) return res.status(400).json({ error: "Price must be greater than zero." });
  let item = memoryMenu.find(x => x._id === req.params.id);
  if (item) {
    if (price !== undefined) item.price = Number(price);
    if (available !== undefined) item.available = Boolean(available);
  }
  if (mongoReady && mongoose.isValidObjectId(req.params.id)) {
    const update = {};
    if (price !== undefined) update.price = Number(price);
    if (available !== undefined) update.available = Boolean(available);
    const doc = await MenuModel.findByIdAndUpdate(req.params.id, update, { new: true });
    if (doc) item = doc.toObject();
  }
  if (!item) return res.status(404).json({ error: "Menu item not found." });
  await publishEvent({ type: "MenuUpdated", itemId: req.params.id, price: item.price, available: item.available, at: new Date().toISOString() });
  res.json(item);
});

app.post("/api/orders", async (req, res) => {
  const { customerName, address, items, paymentMethod = "UPI", idempotencyKey } = req.body;
  if (!customerName?.trim() || !address?.trim() || !Array.isArray(items) || !items.length) {
    return res.status(400).json({ error: "Name, address, and at least one cart item are required." });
  }
  if (!idempotencyKey) return res.status(400).json({ error: "idempotencyKey is required." });

  // Simple in-process duplicate protection for this teaching demo.
  const existing = memoryOrders.find(o => o.idempotencyKey === idempotencyKey);
  if (existing) return res.status(200).json(existing);

  let total = 0;
  const cleanItems = [];
  for (const cartItem of items) {
    const menuItem = memoryMenu.find(m => m._id === cartItem.itemId);
    const quantity = Number(cartItem.quantity);
    if (!menuItem || !menuItem.available) return res.status(409).json({ error: "An item is unavailable. Refresh the menu and try again." });
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 20) return res.status(400).json({ error: "Quantity must be between 1 and 20." });
    cleanItems.push({ itemId: menuItem._id, name: menuItem.name, price: menuItem.price, quantity });
    total += menuItem.price * quantity;
  }
  const order = {
    id: `FD-${Date.now().toString().slice(-7)}`, customerName: customerName.trim(), address: address.trim(),
    items: cleanItems, total, paymentMethod, paymentStatus: paymentMethod === "Cash on delivery" ? "Pay on delivery" : "Demo payment successful",
    status: "Placed", createdAt: new Date().toISOString(), idempotencyKey
  };
  memoryOrders.unshift(order);
  if (mongoReady) {
    try {
      const saved = await OrderModel.create({ ...order, _id: undefined });
      order.mongoId = String(saved._id);
    } catch (err) { console.error("Order database save failed; keeping demo-memory order:", err.message); }
  }
  await publishEvent({ type: "OrderPlaced", orderId: order.id, customerName: order.customerName, total: order.total, at: order.createdAt });
  res.status(201).json(order);
});

app.get("/api/orders", async (_req, res) => {
  res.json(memoryOrders);
});

app.get("/api/orders/:id", async (req, res) => {
  const order = memoryOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  res.json(order);
});

app.patch("/api/orders/:id/status", async (req, res) => {
  const allowed = ["Confirmed", "Preparing", "Picked Up", "Out for Delivery", "Delivered", "Cancelled", "Rejected"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid order status." });
  const order = memoryOrders.find(o => o.id === req.params.id);
  if (!order) return res.status(404).json({ error: "Order not found." });
  order.status = req.body.status;
  await publishEvent({ type: "OrderStatusUpdated", orderId: order.id, status: order.status, at: new Date().toISOString() });
  res.json(order);
});

async function start() {
  const port = process.env.PORT || 5000;
  try {
    await mongoose.connect(process.env.MONGODB_URI || "mongodb://127.0.0.1:27017/food_delivery_demo", { serverSelectionTimeoutMS: 1800 });
    mongoReady = true;
    console.log("MongoDB connected");
    if (!(await MenuModel.countDocuments())) await MenuModel.insertMany(menuSeed);
  } catch (err) {
    console.warn("MongoDB unavailable; using in-memory demo data:", err.message);
  }
  try {
    const conn = await amqp.connect(process.env.RABBITMQ_URL || "amqp://localhost");
    rabbitChannel = await conn.createChannel();
    await rabbitChannel.assertExchange("food.events", "fanout", { durable: true });
    console.log("RabbitMQ connected");
  } catch (err) {
    console.warn("RabbitMQ unavailable; notifications will be skipped:", err.message);
  }
  app.listen(port, () => console.log(`Food delivery API running at http://localhost:${port}`));
}
start();
