import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Search, ShoppingBag, MapPin, Clock, Star, Plus, Minus, Trash2, Bike, Utensils, PackageCheck, Store, Bell, X, CheckCircle2, ChefHat } from 'lucide-react';
import './styles.css';

const API = 'http://localhost:5000/api';
const money = n => `₹${Number(n).toFixed(0)}`;
const images = {
  "Margherita Pizza":"https://images.unsplash.com/photo-1579751626657-72bc17010498?auto=format&fit=crop&w=800&q=80",
  "Classic Burger":"https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80",
  "Paneer Wrap":"https://images.unsplash.com/photo-1626700051175-6818013e1d4f?auto=format&fit=crop&w=800&q=80",
  "Masala Dosa":"https://images.unsplash.com/photo-1668236543090-82eba5ee5976?auto=format&fit=crop&w=800&q=80",
  "Chocolate Brownie":"https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80",
  "Crispy Fries":"https://images.unsplash.com/photo-1573080496219-bb080dd4f877?auto=format&fit=crop&w=800&q=80"
};
const fallbackMenu = [
  {_id:'m1',name:'Margherita Pizza',restaurant:'Urban Oven',category:'Pizza',price:249,available:true,emoji:'🍕'},
  {_id:'m2',name:'Classic Burger',restaurant:'Burger House',category:'Burgers',price:159,available:true,emoji:'🍔'},
  {_id:'m3',name:'Paneer Wrap',restaurant:'Green Bowl',category:'Wraps',price:129,available:true,emoji:'🌯'},
  {_id:'m4',name:'Masala Dosa',restaurant:'South Spice',category:'South Indian',price:99,available:true,emoji:'🥞'},
  {_id:'m5',name:'Chocolate Brownie',restaurant:'Sweet Spot',category:'Desserts',price:89,available:true,emoji:'🍫'},
  {_id:'m6',name:'Crispy Fries',restaurant:'Burger House',category:'Sides',price:79,available:true,emoji:'🍟'}
];

function App() {
  const [menu,setMenu] = useState(fallbackMenu);
  const [orders,setOrders] = useState([]);
  const [cart,setCart] = useState(() => JSON.parse(localStorage.getItem('crave-cart') || '[]'));
  const [page,setPage] = useState('home');
  const [query,setQuery] = useState('');
  const [category,setCategory] = useState('All');
  const [toast,setToast] = useState('');
  const [busy,setBusy] = useState(false);
  const [form,setForm] = useState({customerName:'Alex Morgan',address:'12 Green Park Road, Chennai',paymentMethod:'UPI'});
  const [activeOrder,setActiveOrder] = useState(null);
  const [health,setHealth] = useState({database:'demo mode',rabbitmq:'optional'});
  const [tab,setTab] = useState('orders');

  useEffect(() => {
    fetch(`${API}/menu`).then(r=>r.json()).then(setMenu).catch(()=>{});
    fetch(`${API}/health`).then(r=>r.json()).then(setHealth).catch(()=>{});
    fetch(`${API}/orders`).then(r=>r.json()).then(setOrders).catch(()=>{});
  },[]);
  useEffect(()=>localStorage.setItem('crave-cart',JSON.stringify(cart)),[cart]);
  const categories = ['All',...new Set(menu.map(i=>i.category))];
  const filtered = useMemo(()=>menu.filter(i=>(category==='All'||i.category===category)&&(`${i.name} ${i.restaurant} ${i.category}`).toLowerCase().includes(query.toLowerCase())),[menu,category,query]);
  const count = cart.reduce((n,i)=>n+i.quantity,0);
  const subtotal = cart.reduce((n,i)=>n+i.price*i.quantity,0);
  const deliveryFee = subtotal ? 25 : 0;
  const total = subtotal + deliveryFee;

  function notify(message){setToast(message);setTimeout(()=>setToast(''),2800);}
  function add(item){
    if(!item.available) return notify('This item is currently unavailable.');
    setCart(old=>{const found=old.find(i=>i._id===item._id);return found?old.map(i=>i._id===item._id?{...i,quantity:i.quantity+1}:i):[...old,{...item,quantity:1}]});
    notify(`${item.name} added to cart`);
  }
  function changeQty(id,delta){setCart(old=>old.map(i=>i._id===id?{...i,quantity:i.quantity+delta}:i).filter(i=>i.quantity>0));}
  async function refreshOrders(){try{setOrders(await (await fetch(`${API}/orders`)).json())}catch{}}
  async function placeOrder(e){
    e.preventDefault();
    if(!cart.length) return notify('Add an item before checkout.');
    setBusy(true);
    try {
      const key = `crave-${Date.now()}-${Math.random().toString(36).slice(2,8)}`;
      const res = await fetch(`${API}/orders`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({ ...form, items:cart.map(i=>({itemId:i._id,quantity:i.quantity})),idempotencyKey:key })});
      const data = await res.json();
      if(!res.ok) throw new Error(data.error || 'Could not place order');
      setActiveOrder(data);setCart([]);setPage('tracking');await refreshOrders();notify('Order placed successfully!');
    } catch(err){notify(err.message || 'Backend unavailable. Start the backend first.');}
    finally{setBusy(false);}
  }
  async function updateStatus(order,status){
    try {
      const res=await fetch(`${API}/orders/${order.id}/status`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({status})});
      const data=await res.json();if(!res.ok)throw new Error(data.error||'Update failed');
      setActiveOrder(data);await refreshOrders();notify(`Order status: ${status}`);
    } catch(err){notify(err.message);}
  }
  async function updateMenu(item,changes){
    try {
      const res=await fetch(`${API}/menu/${item._id}`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify(changes)});
      const data=await res.json();if(!res.ok)throw new Error(data.error||'Could not update item');
      setMenu(old=>old.map(i=>i._id===item._id?{...i,...data}:i));notify('Menu updated');
    }catch(err){notify(err.message);}
  }

  const go = p => {setPage(p);if(p==='orders')refreshOrders();};
  return <div className="app">
    <header className="topbar"><button className="brand" onClick={()=>go('home')}><span className="brand-mark">c</span><span>crave<span className="brand-dot">.</span><small>GOOD FOOD, GOOD MOOD</small></span></button>
      <div className="location"><MapPin size={17}/><span><b>Delivering to</b><small>Chennai, Tamil Nadu</small></span></div>
      <div className="nav-links"><button className={page==='home'?'active':''} onClick={()=>go('home')}>Explore</button><button className={page==='orders'?'active':''} onClick={()=>go('orders')}>My orders</button><button className={page==='restaurant'?'active':''} onClick={()=>go('restaurant')}>Restaurant</button></div>
      <button className="cart-button" onClick={()=>go('cart')}><ShoppingBag size={18}/> Cart <span>{count}</span></button>
    </header>
    <main>
      {page==='home' && <>
        <section className="hero"><div className="hero-copy"><span className="eyebrow"><span className="eyebrow-dot"/> YOUR NEXT FAVOURITE MEAL</span><h1>Cravings?<br/><em>Consider it</em> delivered.</h1><p>Delicious picks from local favourites, delivered right to your door.</p><div className="hero-search"><Search size={19}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search dishes or restaurants"/><button onClick={()=>document.getElementById('menu-section')?.scrollIntoView({behavior:'smooth'})}>Find food</button></div><div className="hero-points"><span><Clock size={15}/> Quick delivery</span><span><Star size={15} fill="currentColor"/> Local favourites</span></div></div><div className="hero-art"><div className="hero-circle"/><div className="hero-food">🍕</div><div className="floating-card rating"><Star size={15} fill="currentColor"/> <b>4.9</b><small>Food lovers agree</small></div><div className="floating-card delivery"><Bike size={19}/><span><b>At your door</b><small>In about 25 mins</small></span></div><span className="art-spark spark-one">✳</span><span className="art-spark spark-two">✦</span></div></section>
        <section className="trust-row"><div><span className="trust-icon orange"><Clock/></span><span><b>Fast delivery</b><small>Good food, right on time</small></span></div><div><span className="trust-icon green"><ChefHat/></span><span><b>Local favourites</b><small>Handpicked for your cravings</small></span></div><div><span className="trust-icon purple"><PackageCheck/></span><span><b>Easy ordering</b><small>From menu to doorstep</small></span></div></section>
        <section id="menu-section" className="menu-section"><div className="section-heading"><div><span className="eyebrow">A LITTLE SOMETHING FOR EVERYONE</span><h2>Popular near you<span>.</span></h2><p>Fresh picks worth staying in for.</p></div><span className="result-count">{filtered.length} delicious picks</span></div>
          <div className="category-row">{categories.map(c=><button key={c} onClick={()=>setCategory(c)} className={category===c?'selected':''}>{c==='All'?'✨':c==='Pizza'?'🍕':c==='Burgers'?'🍔':c==='Wraps'?'🌯':c==='South Indian'?'🥞':c==='Desserts'?'🍰':'🍟'} <span>{c}</span></button>)}</div>
          <div className="food-grid">{filtered.map((item,i)=><article className="food-card" key={item._id}><div className="food-photo"><img src={images[item.name]||images['Margherita Pizza']} alt={item.name}/><span className="veg-dot" title="Vegetarian"/> <span className="food-tag">{i===0?'POPULAR':item.category.toUpperCase()}</span><button className="quick-add" disabled={!item.available} onClick={()=>add(item)}><Plus size={18}/></button></div><div className="food-info"><div className="food-title"><h3>{item.name}</h3><span className="rating-mini"><Star size={12} fill="currentColor"/> 4.8</span></div><p>{item.restaurant} <span>•</span> {item.category}</p><div className="food-bottom"><b>{money(item.price)}</b><span><Clock size={13}/> 20–30 min</span></div>{!item.available&&<small className="unavailable">Currently unavailable</small>}</div></article>)}</div>
          {filtered.length===0&&<div className="empty"><span>🍽️</span><h3>No dishes found</h3><p>Try another search or category.</p></div>}
        </section>
        <section className="bottom-banner"><div><span className="eyebrow">A GOOD MEAL IS JUST A FEW CLICKS AWAY</span><h2>Let’s make tonight<br/>a little more delicious.</h2><button className="primary" onClick={()=>document.getElementById('menu-section')?.scrollIntoView({behavior:'smooth'})}>Explore the menu <span>→</span></button></div><div className="banner-emoji">🥗</div></section>
      </>}
      {page==='cart'&&<section className="inner-page"><button className="back-link" onClick={()=>go('home')}>← Continue browsing</button><div className="section-heading"><div><span className="eyebrow">YOUR ORDER</span><h2>Your cart<span>.</span></h2><p>All the good stuff, in one place.</p></div></div>{!cart.length?<div className="empty cart-empty"><span>🛍️</span><h3>Your cart is taking a little break</h3><p>Add something tasty from the menu to get started.</p><button className="primary" onClick={()=>go('home')}>Browse menu</button></div>:<div className="checkout-layout"><div className="cart-list">{cart.map(i=><div className="cart-item" key={i._id}><img src={images[i.name]||images['Margherita Pizza']} alt=""/><div className="cart-item-name"><h3>{i.name}</h3><p>{i.restaurant}</p><b>{money(i.price)}</b></div><div className="qty"><button onClick={()=>changeQty(i._id,-1)}><Minus size={14}/></button><b>{i.quantity}</b><button onClick={()=>changeQty(i._id,1)}><Plus size={14}/></button></div><button className="remove" onClick={()=>changeQty(i._id,-i.quantity)}><Trash2 size={17}/></button></div>)}</div><form className="checkout-card" onSubmit={placeOrder}><h3>Delivery details</h3><label>Your name<input required value={form.customerName} onChange={e=>setForm({...form,customerName:e.target.value})}/></label><label>Delivery address<textarea required rows="2" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/></label><label>Payment method<select value={form.paymentMethod} onChange={e=>setForm({...form,paymentMethod:e.target.value})}><option>UPI</option><option>Card</option><option>Cash on delivery</option></select></label><div className="bill"><div><span>Subtotal</span><b>{money(subtotal)}</b></div><div><span>Delivery fee</span><b>{money(deliveryFee)}</b></div><div className="bill-total"><span>Total</span><b>{money(total)}</b></div></div><button className="primary full" disabled={busy}>{busy?'Placing order…':`Place order · ${money(total)}`}</button><small className="demo-note">Demo checkout · no real payment is taken.</small></form></div>}</section>}
      {page==='tracking'&&<section className="inner-page"><button className="back-link" onClick={()=>go('orders')}>← My orders</button><div className="tracking-hero"><div className="success-icon"><CheckCircle2 size={34}/></div><span className="eyebrow">ORDER CONFIRMED</span><h2>Your food journey<br/>starts here<span>.</span></h2><p>Order {activeOrder?.id||'placed'} · {activeOrder?.paymentStatus||'Demo payment'}</p></div>{activeOrder&&<div className="tracking-card"><div className="tracking-card-head"><div><span className="eyebrow">LIVE ORDER STATUS</span><h3>{activeOrder.status}</h3></div><span className="status-pill">{activeOrder.status}</span></div><div className="timeline">{['Placed','Confirmed','Preparing','Picked Up','Out for Delivery','Delivered'].map((s,i)=>{const steps=['Placed','Confirmed','Preparing','Picked Up','Out for Delivery','Delivered'];const curr=steps.indexOf(activeOrder.status);return <div className={`timeline-step ${i<=curr?'done':''}`} key={s}><span className="timeline-dot">{i<curr?'✓':i+1}</span><div><b>{s}</b><small>{i===0?'We received your order':i===1?'Restaurant confirmed your order':i===2?'Your meal is being prepared':i===3?'Order picked up by delivery partner':i===4?'On its way to you':'Enjoy your meal!'}</small></div></div>})}</div><div className="tracking-order-items"><h4>Order summary</h4>{activeOrder.items?.map((i,idx)=><div key={idx}><span>{i.quantity} × {i.name}</span><b>{money(i.price*i.quantity)}</b></div>)}<div className="bill-total"><span>Total paid / due</span><b>{money(activeOrder.total)}</b></div></div></div>}</section>}
      {page==='orders'&&<section className="inner-page"><div className="section-heading"><div><span className="eyebrow">YOUR CRAVE HISTORY</span><h2>My orders<span>.</span></h2><p>Every good bite, all in one place.</p></div><button className="outline-button" onClick={refreshOrders}>↻ Refresh</button></div>{orders.length===0?<div className="empty"><span>🧾</span><h3>No orders just yet</h3><p>Your next favourite meal is waiting.</p><button className="primary" onClick={()=>go('home')}>Explore food</button></div>:<div className="orders-list">{orders.map(o=><article className="order-card" key={o.id}><div className="order-card-icon">🍱</div><div className="order-card-main"><div className="order-top"><h3>Order {o.id}</h3><span className="status-pill">{o.status}</span></div><p>{o.items.map(i=>`${i.quantity} × ${i.name}`).join(', ')}</p><small>{new Date(o.createdAt).toLocaleString()}</small></div><div className="order-card-right"><b>{money(o.total)}</b><button onClick={()=>{setActiveOrder(o);go('tracking')}}>Track order →</button></div></article>)}</div>}</section>}
      {page==='restaurant'&&<section className="inner-page"><div className="section-heading"><div><span className="eyebrow">PARTNER WORKSPACE</span><h2>Restaurant desk<span>.</span></h2><p>Manage incoming orders and keep your menu fresh.</p></div><span className="dashboard-tag"><Store size={15}/> DEMO DASHBOARD</span></div><div className="dashboard-tabs"><button className={tab==='orders'?'selected':''} onClick={()=>setTab('orders')}>Incoming orders ({orders.length})</button><button className={tab==='menu'?'selected':''} onClick={()=>setTab('menu')}>Menu management</button></div>{tab==='orders'?<div className="orders-list">{orders.length===0?<div className="empty"><span>📥</span><h3>All quiet for now</h3><p>New customer orders will appear here.</p></div>:orders.map(o=><article className="order-card" key={o.id}><div className="order-card-icon">🍽️</div><div className="order-card-main"><div className="order-top"><h3>{o.id}</h3><span className="status-pill">{o.status}</span></div><p>{o.customerName} · {o.items.map(i=>`${i.quantity} × ${i.name}`).join(', ')}</p><small>{o.address}</small></div><div className="order-actions"><button onClick={()=>updateStatus(o,'Confirmed')}>Accept</button><button onClick={()=>updateStatus(o,'Rejected')}>Reject</button><select aria-label="Update status" value={o.status} onChange={e=>updateStatus(o,e.target.value)}><option value={o.status}>{o.status}</option>{['Preparing','Picked Up','Out for Delivery','Delivered','Cancelled'].filter(s=>s!==o.status).map(s=><option key={s}>{s}</option>)}</select></div></article>)}</div>:<div className="menu-admin">{menu.map(item=><div className="menu-admin-row" key={item._id}><img src={images[item.name]||images['Margherita Pizza']} alt=""/><div><b>{item.name}</b><small>{item.restaurant}</small></div><label>Price ₹<input type="number" min="1" defaultValue={item.price} onBlur={e=>{if(Number(e.target.value)!==item.price)updateMenu(item,{price:Number(e.target.value)})}}/></label><label className="availability-toggle"><input type="checkbox" checked={item.available} onChange={e=>updateMenu(item,{available:e.target.checked})}/> Available</label></div>)}</div>}</section>}
    </main>
    <footer><button className="footer-brand" onClick={()=>go('home')}>crave<span>.</span></button><p>Good food. Good mood. Made for your cravings.</p><div className="footer-meta"><span>Demo application</span><span className="status-dot"/> <span>API: {health.status==='ok'?'Connected':'Try localhost:5000'}</span><span>· {health.database||'demo mode'}</span></div></footer>
    {toast&&<div className="toast"><CheckCircle2 size={18}/>{toast}<button onClick={()=>setToast('')}><X size={15}/></button></div>}
  </div>;
}

createRoot(document.getElementById('root')).render(<App />);
